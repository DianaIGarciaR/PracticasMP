from setuptools import setup

setup(
    name="mpb22p1",
    author="Diana Itzel Garcia Rodriguez",
    packages=["src","src.mpb22.eda"]
)